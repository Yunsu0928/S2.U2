const Grub = require('./Grub');

class Bee extends Grub{
  constructor(age=5, job='Keep on growing'){
    super(age, "yellow")
    this.job = job;
  }
}

module.exports = Bee;