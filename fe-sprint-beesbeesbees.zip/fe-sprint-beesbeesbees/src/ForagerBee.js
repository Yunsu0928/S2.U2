const Bee = require('./Bee');

class ForagerBee extends Bee{
  constructor(){
    super(10, 'find pollen')
    this.canFly = true
    this.treasureChest = []
  }
  forage(a){ this.treasureChest.push(a)}
}

module.exports = ForagerBee;
