const Bee = require('./Bee');

class HoneyMakerBee extends Bee{
  constructor(age=10, job = 'make honey'){
    super(age, job)
    this.honeyPot = 0;
  }
  makeHoney(){ this.honeyPot += 1 }
  giveHoney(){ this.honeyPot -= 1 }
}

module.exports = HoneyMakerBee;
