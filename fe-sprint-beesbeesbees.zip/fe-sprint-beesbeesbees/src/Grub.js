class Grub {

  constructor(age = 0, color = 'pink', food = 'jelly'){
    this.age = age;
    this.color = color;
    this.food = food;
  }

  eat(){return 'Mmmmmmmmm jelly'}
}

module.exports = Grub;